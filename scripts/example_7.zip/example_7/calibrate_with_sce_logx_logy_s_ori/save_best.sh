#!/bin/bash

set -e

echo "saving input files for the best solution found ..."

if [ ! -e best ] ; then
    mkdir best
fi

cp parameters.py           best/parameters.py
cp objective_function.out  best/objective_function.out

exit 0
