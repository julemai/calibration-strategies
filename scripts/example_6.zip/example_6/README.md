## Create 10 trials using DDS
cd calibrate_with_dds
./run_all.sh

## Retrieve all results from trials and create CSV
python figure_1.py
