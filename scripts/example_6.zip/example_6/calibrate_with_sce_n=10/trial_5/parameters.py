#! /usr/bin/env python
# -*- coding: utf-8 -*-
#
#
# Copyright 2016-2021 Juliane Mai - juliane.mai(at)uwaterloo.ca
#
# License
# This file is part of Juliane Mai's personal code library.
#
# Juliane Mai's personal code library is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Juliane Mai's personal code library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.

# You should have received a copy of the GNU Lesser General Public License
# along with Juliane Mai's personal code library.  If not, see <http://www.gnu.org/licenses/>.
#
# parameters for example 1 function


# parameters
p01 = 1.146550E-01
p02 = 9.694955E-02
p03 = -2.513208E-01
p04 = 9.719591E-02
p05 = -4.232085E-02
p06 = -8.546558E-03
p07 = 7.388772E-02
p08 = -2.549588E-02
p09 = 3.307604E-02
p10 = -1.084344E-01
