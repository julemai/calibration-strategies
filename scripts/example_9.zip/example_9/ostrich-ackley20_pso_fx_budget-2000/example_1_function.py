#!/usr/bin/env python

# Copyright 2019 Juliane Mai - juliane.mai(at)uwaterloo.ca
#
# License
# This file is part of Juliane Mai's personal code library.
#
# Juliane Mai's personal code library is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Juliane Mai's personal code library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.

# You should have received a copy of the GNU Lesser General Public Licensefstop
# along with Juliane Mai's personal code library.  If not, see <http://www.gnu.org/licenses/>.
#
# run with:
#     run example_1_function.py -t 'dds' -o 'objective_function.out'

#!/usr/bin/env python
from __future__ import print_function

"""

Plots results of PieShare distribution

History
-------
Written,  JM, Jun 2021
"""

# -------------------------------------------------------------------------
if __name__ == '__main__':

    import argparse
    import numpy      as np
    from parameters import p01, p02, p03, p04, p05, p06, p07, p08, p09, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20

    sampletype     = 'dds'
    outfile        = 'objective_function.out'

    parser   = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter,
                                      description='''Parameter sampling using calibration algorithm.''')
    parser.add_argument('-o', '--outfile', action='store',
                        default=outfile, dest='outfile', metavar='outfile',
                        help='File containing the objective function (MSE) of the function using parameters in specified file parameters.py and the true parameter setting.')
    parser.add_argument('-t', '--sampletype', action='store',
                        default=sampletype, dest='sampletype', metavar='sampletype',
                        help='Type of sampling. Either "dds" (default: "dds").')

    args       = parser.parse_args()
    sampletype = args.sampletype
    outfile    = args.outfile

    del parser, args

    def objective_function(p):

        # two-dimensional Gaussian function as described on Wikipedia using parameters described there
        # https://en.wikipedia.org/wiki/Gaussian_function

        # optimum at p1=x=0.0 and p2=y=0.0 is A=1.0
        A = 1.0
        a = 0.5
        b = 0.0
        c = 0.125

        x0 = 0.0
        y0 = 0.0

        func = A * np.exp(-(a*(p[0] - x0)**2 + 2*b*(p[0] - x0)*(p[1] - y0) + c*(p[1] - y0)**2))

        return func

    def ackley(x):
        """
        Ackley function (>= 2-D).

        Global Optimum: 0.0, at origin.

        Parameters
        ----------
        x : array
            multi-dimensional x-values (len(x) >= 2)

        Returns
        -------
        float
           Value of Ackley function.
        """
        a = 20.0
        b = 0.2
        c = 2.0*np.pi

        n  = np.size(x)
        s1 = np.sum(x**2)
        s2 = np.sum(np.cos(c*x))
        f  = -a * np.exp(-b*np.sqrt(1.0/n*s1)) - np.exp(1.0/n*s2) + a + np.exp(1.0)

        return f

    # derive objective function (NSE)
    # nse = objective_function([p1,p2])
    fx = ackley(np.array([p01, p02,p03, p04, p05, p06, p07, p08, p09, p10, p11, p12,p13, p14, p15, p16, p17, p18, p19, p20]))

    # write f(x) to file (for Ostrich)
    ff = open(outfile,'w')
    ff.write('fx,'+str(fx))
    ff.close()
