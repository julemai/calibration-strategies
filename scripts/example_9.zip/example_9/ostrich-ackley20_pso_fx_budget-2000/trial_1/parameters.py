#! /usr/bin/env python
# -*- coding: utf-8 -*-
#
#
# Copyright 2016-2021 Juliane Mai - juliane.mai(at)uwaterloo.ca
#
# License
# This file is part of Juliane Mai's personal code library.
#
# Juliane Mai's personal code library is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Juliane Mai's personal code library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.

# You should have received a copy of the GNU Lesser General Public License
# along with Juliane Mai's personal code library.  If not, see <http://www.gnu.org/licenses/>.
#
# parameters for example 1 function


# parameters
p01 = -3.597343E-02
p02 = -9.907284E-02
p03 = -3.249692E-02
p04 = 3.185165E-02
p05 = 4.018295E-02
p06 = -7.642741E-02
p07 = -3.124708E-03
p08 = -4.446971E-02
p09 = -1.893453E-02
p10 = 4.196759E-02
p11 = -6.139018E-02
p12 = -3.971718E-02
p13 = -2.879557E-02
p14 = 1.268192E-02
p15 = 6.529265E-02
p16 = -8.323177E-02
p17 = 8.284316E-03
p18 = -6.350649E-02
p19 = -1.441388E-02
p20 = 1.261159E-01
