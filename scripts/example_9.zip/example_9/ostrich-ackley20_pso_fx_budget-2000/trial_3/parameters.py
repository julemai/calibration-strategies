#! /usr/bin/env python
# -*- coding: utf-8 -*-
#
#
# Copyright 2016-2021 Juliane Mai - juliane.mai(at)uwaterloo.ca
#
# License
# This file is part of Juliane Mai's personal code library.
#
# Juliane Mai's personal code library is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Juliane Mai's personal code library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.

# You should have received a copy of the GNU Lesser General Public License
# along with Juliane Mai's personal code library.  If not, see <http://www.gnu.org/licenses/>.
#
# parameters for example 1 function


# parameters
p01 = -2.434414E-03
p02 = 2.299189E-03
p03 = -6.749585E-03
p04 = -6.732860E-03
p05 = -1.520185E-02
p06 = 1.101060E-02
p07 = -7.042130E-03
p08 = 7.214435E-01
p09 = 1.594944E-02
p10 = -7.410274E-03
p11 = 1.208030E-02
p12 = 7.284039E-03
p13 = 7.012007E-03
p14 = 1.668712E-02
p15 = -3.767888E-04
p16 = 4.161315E-02
p17 = -8.665730E-03
p18 = -3.985816E-03
p19 = 6.981223E-03
p20 = 7.410472E-03
