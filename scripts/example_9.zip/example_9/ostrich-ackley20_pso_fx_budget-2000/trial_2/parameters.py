#! /usr/bin/env python
# -*- coding: utf-8 -*-
#
#
# Copyright 2016-2021 Juliane Mai - juliane.mai(at)uwaterloo.ca
#
# License
# This file is part of Juliane Mai's personal code library.
#
# Juliane Mai's personal code library is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Juliane Mai's personal code library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.

# You should have received a copy of the GNU Lesser General Public License
# along with Juliane Mai's personal code library.  If not, see <http://www.gnu.org/licenses/>.
#
# parameters for example 1 function


# parameters
p01 = 4.246386E-02
p02 = -1.406683E-02
p03 = -4.439131E-03
p04 = -5.883663E-03
p05 = -1.811924E-02
p06 = 3.331574E-02
p07 = -1.385442E-02
p08 = 5.970728E-02
p09 = 1.824950E-02
p10 = -3.584940E-02
p11 = -1.192487E-02
p12 = 3.633804E-03
p13 = 2.853778E-03
p14 = 1.254022E-02
p15 = 4.488214E-03
p16 = 6.832344E-03
p17 = 2.537483E-02
p18 = 5.105577E-02
p19 = -4.091524E-02
p20 = -1.905316E-02
