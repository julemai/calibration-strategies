#! /usr/bin/env python
# -*- coding: utf-8 -*-
#
#
# Copyright 2016-2021 Juliane Mai - juliane.mai(at)uwaterloo.ca
#
# License
# This file is part of Juliane Mai's personal code library.
#
# Juliane Mai's personal code library is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Juliane Mai's personal code library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.

# You should have received a copy of the GNU Lesser General Public License
# along with Juliane Mai's personal code library.  If not, see <http://www.gnu.org/licenses/>.
#
# parameters for example 1 function


# parameters
p01 = -5.012662E-02
p02 = -8.185070E-02
p03 = 4.433285E-02
p04 = -9.214491E-02
p05 = 8.283169E-02
p06 = -3.833183E-02
p07 = -2.505766E-02
p08 = -1.362782E-03
p09 = 2.152080E-01
p10 = -1.159054E-02
# p11 = par_p11
# p12 = par_p12
# p13 = par_p13
# p14 = par_p14
# p15 = par_p15
# p16 = par_p16
# p17 = par_p17
# p18 = par_p18
# p19 = par_p19
# p20 = par_p20
