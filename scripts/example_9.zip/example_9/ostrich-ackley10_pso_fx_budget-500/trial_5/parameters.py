#! /usr/bin/env python
# -*- coding: utf-8 -*-
#
#
# Copyright 2016-2021 Juliane Mai - juliane.mai(at)uwaterloo.ca
#
# License
# This file is part of Juliane Mai's personal code library.
#
# Juliane Mai's personal code library is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Juliane Mai's personal code library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.

# You should have received a copy of the GNU Lesser General Public License
# along with Juliane Mai's personal code library.  If not, see <http://www.gnu.org/licenses/>.
#
# parameters for example 1 function


# parameters
p01 = 4.216454E-02
p02 = -3.728043E-03
p03 = 1.855398E-01
p04 = 6.848617E-02
p05 = -3.227939E-02
p06 = -9.165778E-03
p07 = 5.772894E-03
p08 = 3.424721E-02
p09 = 4.825419E-02
p10 = 3.965047E-03
# p11 = par_p11
# p12 = par_p12
# p13 = par_p13
# p14 = par_p14
# p15 = par_p15
# p16 = par_p16
# p17 = par_p17
# p18 = par_p18
# p19 = par_p19
# p20 = par_p20
