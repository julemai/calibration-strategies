#!/bin/bash
#
# Runs test function with weights sampled follwoing the naive approach

set -e
#
prog=$0
pprog=$(basename ${prog})
dprog=$(dirname ${prog})
isdir=${PWD}
pid=$$



python example_1_function.py -t 'dds' -o objective_function.out
