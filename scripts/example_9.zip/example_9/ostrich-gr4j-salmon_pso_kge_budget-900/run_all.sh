#!/bin/bash
#
# Runs SCE to determine best fit

set -e
#
prog=$0
pprog=$(basename ${prog})
dprog=$(dirname ${prog})
isdir=${PWD}
pid=$$

#pyenv activate env-385-new

for (( itrial=1 ; itrial<=10 ; itrial++ )) ; do

    if [ ! -e trial_${itrial} ] ; then

	if [ -e OstDDSPn.txt ] ;     then rm OstDDSPn.txt ;     fi
	if [ -e OstErrors0.txt ] ;   then rm OstErrors0.txt ;   fi
	if [ -e OstModel0.txt ] ;    then rm OstModel0.txt ;    fi
	if [ -e OstOutput0.txt ] ;   then rm OstOutput0.txt ;   fi
	if [ -e OstProgress0.txt ] ; then rm OstProgress0.txt ; fi
	if [ -e OstStatus0.txt ] ;   then rm OstStatus0.txt ;   fi
	if [ -e processor_0 ] ;      then rm -r processor_0 ;   fi

	./OstrichGCC
	mv processor_0 trial_${itrial}
	mv OstModel0.txt trial_${itrial}/.
	mv OstOutput0.txt trial_${itrial}/.

	# # run best of trial to produce hydrograph
	# cd trial_${itrial}/best/
	# sed 's/:SuppressOutput/# :SuppressOutput/g' raven-gr4j-salmon.rvi > tmp.tmp
	# mv raven-gr4j-salmon.rvi raven-gr4j-salmon.rvi.nooutput
	# mv tmp.tmp raven-gr4j-salmon.rvi
	# ln -s ../model/data_obs .
	# ../model/Raven_rev373_MacOS.exe raven-gr4j-salmon -o output/
	# cd -

	if [ -e OstDDSPn.txt ] ;     then rm OstDDSPn.txt ;     fi
	if [ -e OstErrors0.txt ] ;   then rm OstErrors0.txt ;   fi
	if [ -e OstModel0.txt ] ;    then rm OstModel0.txt ;    fi
	if [ -e OstOutput0.txt ] ;   then rm OstOutput0.txt ;   fi
	if [ -e OstProgress0.txt ] ; then rm OstProgress0.txt ; fi
	if [ -e OstStatus0.txt ] ;   then rm OstStatus0.txt ;   fi
	if [ -e processor_0 ] ;      then rm -r processor_0 ;   fi

    fi

done
