#! /usr/bin/env python
# -*- coding: utf-8 -*-
#
#
# Copyright 2016-2021 Juliane Mai - juliane.mai(at)uwaterloo.ca
#
# License
# This file is part of Juliane Mai's personal code library.
#
# Juliane Mai's personal code library is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Juliane Mai's personal code library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.

# You should have received a copy of the GNU Lesser General Public License
# along with Juliane Mai's personal code library.  If not, see <http://www.gnu.org/licenses/>.
#
# parameters for example 1 function


# parameters
p01 = 4.718549E-02
p02 = -1.685103E-02
p03 = -1.675662E-02
p04 = 1.377031E-02
p05 = 2.077991E-02
p06 = -6.888879E-03
p07 = -5.953842E-02
p08 = 8.210322E-03
p09 = 9.323426E-03
p10 = -9.913853E-02
p11 = 2.445862E-02
p12 = -9.720735E-02
p13 = 5.425280E-03
p14 = -5.663000E-03
p15 = 4.170589E-02
p16 = 4.444850E-02
p17 = 4.154477E-02
p18 = -4.118577E-03
p19 = -6.710963E-03
p20 = 3.842087E-02
