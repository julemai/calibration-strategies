#! /usr/bin/env python
# -*- coding: utf-8 -*-
#
#
# Copyright 2016-2021 Juliane Mai - juliane.mai(at)uwaterloo.ca
#
# License
# This file is part of Juliane Mai's personal code library.
#
# Juliane Mai's personal code library is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Juliane Mai's personal code library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.

# You should have received a copy of the GNU Lesser General Public License
# along with Juliane Mai's personal code library.  If not, see <http://www.gnu.org/licenses/>.
#
# parameters for example 1 function


# parameters
p01 = -1.083930E+00
p02 = 1.585218E-02
p03 = 3.661599E-01
p04 = 7.733981E-02
p05 = -1.735150E-01
p06 = 1.614997E-01
p07 = 5.123071E-02
p08 = 4.496396E-03
p09 = 1.006578E-01
p10 = 6.873940E-02
p11 = 1.069359E-01
p12 = -3.940853E-02
p13 = -1.396596E-01
p14 = -6.587182E-01
p15 = 7.372474E-02
p16 = 8.148999E-02
p17 = -3.263756E-01
p18 = 1.442057E-01
p19 = 4.718363E-01
p20 = 5.493926E-02
