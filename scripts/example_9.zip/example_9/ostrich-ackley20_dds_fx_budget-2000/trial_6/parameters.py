#! /usr/bin/env python
# -*- coding: utf-8 -*-
#
#
# Copyright 2016-2021 Juliane Mai - juliane.mai(at)uwaterloo.ca
#
# License
# This file is part of Juliane Mai's personal code library.
#
# Juliane Mai's personal code library is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Juliane Mai's personal code library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.

# You should have received a copy of the GNU Lesser General Public License
# along with Juliane Mai's personal code library.  If not, see <http://www.gnu.org/licenses/>.
#
# parameters for example 1 function


# parameters
p01 = 1.035083E+00
p02 = 1.090924E+00
p03 = -7.514440E-01
p04 = -5.890214E-02
p05 = 1.261079E-02
p06 = -3.607397E-01
p07 = -1.194576E+00
p08 = -4.346962E-03
p09 = 6.869990E-02
p10 = -6.424082E-01
p11 = 8.790223E-01
p12 = 1.160349E-01
p13 = 6.499530E-02
p14 = -1.046731E+00
p15 = 1.583688E-01
p16 = 9.883947E-01
p17 = -1.493876E-01
p18 = 1.102328E-01
p19 = -3.296073E-01
p20 = -7.924225E-05
