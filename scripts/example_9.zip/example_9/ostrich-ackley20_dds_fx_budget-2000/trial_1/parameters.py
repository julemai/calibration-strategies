#! /usr/bin/env python
# -*- coding: utf-8 -*-
#
#
# Copyright 2016-2021 Juliane Mai - juliane.mai(at)uwaterloo.ca
#
# License
# This file is part of Juliane Mai's personal code library.
#
# Juliane Mai's personal code library is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Juliane Mai's personal code library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.

# You should have received a copy of the GNU Lesser General Public License
# along with Juliane Mai's personal code library.  If not, see <http://www.gnu.org/licenses/>.
#
# parameters for example 1 function


# parameters
p01 = -2.576403E-02
p02 = -1.676305E-03
p03 = -5.607801E-03
p04 = 7.867326E-03
p05 = 2.227870E-02
p06 = -1.580233E-02
p07 = 6.564035E-03
p08 = 5.282051E-03
p09 = 9.587795E-03
p10 = -1.189807E-02
p11 = -4.482578E-03
p12 = -1.863227E-02
p13 = 2.771519E-02
p14 = 1.619761E-02
p15 = -4.310189E-02
p16 = -3.806139E-02
p17 = 5.136904E-02
p18 = -2.734023E-02
p19 = 6.727228E-02
p20 = 3.281781E-02
