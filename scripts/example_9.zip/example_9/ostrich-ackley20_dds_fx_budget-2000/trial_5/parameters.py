#! /usr/bin/env python
# -*- coding: utf-8 -*-
#
#
# Copyright 2016-2021 Juliane Mai - juliane.mai(at)uwaterloo.ca
#
# License
# This file is part of Juliane Mai's personal code library.
#
# Juliane Mai's personal code library is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Juliane Mai's personal code library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.

# You should have received a copy of the GNU Lesser General Public License
# along with Juliane Mai's personal code library.  If not, see <http://www.gnu.org/licenses/>.
#
# parameters for example 1 function


# parameters
p01 = -2.987103E-02
p02 = -3.752092E-02
p03 = 2.943827E-02
p04 = -1.462282E-03
p05 = -1.981311E-02
p06 = 1.189675E-02
p07 = 1.793315E-02
p08 = 1.564255E-02
p09 = 1.480543E-02
p10 = -3.041574E-03
p11 = -3.771515E-02
p12 = -1.735593E-02
p13 = -3.907915E-02
p14 = -4.993068E-03
p15 = 2.855244E-02
p16 = -3.388212E-03
p17 = 3.107693E-04
p18 = -4.787680E-03
p19 = -2.446446E-03
p20 = -1.645295E-02
