#! /usr/bin/env python
# -*- coding: utf-8 -*-
#
#
# Copyright 2016-2021 Juliane Mai - juliane.mai(at)uwaterloo.ca
#
# License
# This file is part of Juliane Mai's personal code library.
#
# Juliane Mai's personal code library is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Juliane Mai's personal code library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.

# You should have received a copy of the GNU Lesser General Public License
# along with Juliane Mai's personal code library.  If not, see <http://www.gnu.org/licenses/>.
#
# parameters for example 1 function


# parameters
p01 = 1.536346E+00
p02 = -5.811825E-01
p03 = 6.068459E-02
p04 = -1.122509E+00
p05 = 8.887855E-01
p06 = -5.050066E-01
p07 = -5.504605E-01
p08 = 9.154561E-01
p09 = 1.970143E+00
p10 = -1.702417E+00
p11 = 1.922160E+00
p12 = -9.178799E-01
p13 = 1.563927E+00
p14 = -3.922214E-01
p15 = -9.057182E-01
p16 = -4.172656E-01
p17 = 3.525725E-01
p18 = 6.804902E-01
p19 = 1.123594E+00
p20 = -2.973839E-01
