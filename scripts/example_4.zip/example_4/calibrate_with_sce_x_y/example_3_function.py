#!/usr/bin/env python

# Copyright 2019 Juliane Mai - juliane.mai(at)uwaterloo.ca
#
# License
# This file is part of Juliane Mai's personal code library.
#
# Juliane Mai's personal code library is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Juliane Mai's personal code library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.

# You should have received a copy of the GNU Lesser General Public Licensefstop
# along with Juliane Mai's personal code library.  If not, see <http://www.gnu.org/licenses/>.
#
# run with:
#     run example_1_function.py -o 'objective_function.out'

#!/usr/bin/env python
from __future__ import print_function

"""

Derives RMSE of logistic function vs log-log transformed data points

History
-------
Written,  JM, Jun 2022
"""

# -------------------------------------------------------------------------
if __name__ == '__main__':

    import argparse
    import numpy      as np
    from parameters import p01, p02, p03, p04

    outfile        = 'objective_function.out'

    parser   = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter,
                                      description='''Parameter sampling using calibration algorithm.''')
    parser.add_argument('-o', '--outfile', action='store',
                        default=outfile, dest='outfile', metavar='outfile',
                        help='Derives RMSE of logistic function vs log-log transformed data points.')

    args       = parser.parse_args()
    outfile    = args.outfile

    del parser, args

    def rmse_data(p):

        # data borrowed from Katharina Ross

        xvals = np.array([20000, 23, 3500, 4000, 2000, 122, 91, 15, 600, 91, 6, 800,
                          800, 17, 20000, 55, 50000, 14000, 4.4, 4.4, 4.4, 10.4,
                          10.4, 10.4, 100, 110, 500, 8, 8, 25, 13000, 18000, 4, 5,
                          16.4, 290, 8, 3, 1000, 32000, 11, 20, 40, 16, 43, 20000,
                          6.4, 10000, 3200, 5.3, 10.7, 25, 50, 490, 700, 43400, 30,
                          538, 700, 37, 105, 200, 79.2, 4.6, 100000])
        yvals = np.array([30.5, 5.2, 6, 460, 170, 15, 20, 3, 45, 11.6, 11, 15, 12, 2,
                          91, 38.1, 140, 30.5, 0.1, 0.01, 0.2, 0.3, 0.04, 0.7, 6.7,
                          10, 58, 3.1, 1, 1.6, 30.5, 30.5, 0.06, 0.01, 2.74, 41, 0.5,
                          0.03, 21.3, 21.5, 5, 2, 8, 4, 11, 910, 15.2, 61, 61, 0.3,
                          0.46, 11, 25, 6.7, 7.6, 91.4, 12.5, 134, 182, 131, 208, 234,
                          15.2, 0.55, 22800])

        nn = np.shape(xvals)[0]

        # ---------------------------
        # function in x-y space
        # ---------------------------
        # f(x) = 10.0 ^ ( L/(1 + Exp[-k*(Log10[x] - x0)]) - s )

        #    p01 = L,     the curve's maximum value;
        #    p02 = k,     the logistic growth rate or steepness of the curve.
        #    p03 = x0,    the x value of the sigmoid's midpoint;
        #    p04 = s,     the shift of entire function up or down
        ymod = 10. ** ( p[0] / ( 1.0 + np.exp(-p[1]*(np.log10(xvals) - p[2])) ) - p[3] )

        rmse = np.sqrt( ( np.sum( (yvals - ymod)**2 ) ) / (1.0*nn) )

        print(">>>>>>>>>>>>>>>> ",p,"   rmse = ",rmse)

        return rmse


    # derive objective function (RMSE)
    rmse = rmse_data(np.array([p01, p02, p03, p04]))

    # write RMSE to file (for Ostrich)
    ff = open(outfile,'w')
    ff.write('rmse,'+str(rmse))
    ff.close()
