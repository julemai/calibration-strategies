#!/bin/bash

set -e

cp ./raven-gr4j-salmon.rvp model/raven-gr4j-salmon.rvp
cp ./raven-gr4j-salmon.rvc model/raven-gr4j-salmon.rvc

cd model

./Raven_rev373_MacOS.exe raven-gr4j-salmon -o output/

cd ..

exit 0
