#!/usr/bin/env python
from __future__ import print_function

# Copyright 2016-2022 Juliane Mai - juliane.mai(at)uwaterloo.ca
#
# License
# This file is part of Juliane Mai's personal code library.
#
# Juliane Mai's personal code library is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Juliane Mai's personal code library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Lesser General Public License for more details.

# You should have received a copy of the GNU Lesser General Public License
# along with Juliane Mai's personal code library.  If not, see <http://www.gnu.org/licenses/>.



# Comment|Uncomment - Begin
if __name__ == '__main__':

    import argparse

    file_in     = None
    file_out    = None
    start_date  = None
    end_date    = None

    parser   = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter,
                                      description='''Derives KGE metrics (and its components) fromRaven output file.''')
    parser.add_argument('-i', '--file_in', action='store',
                        default=file_in, dest='file_in', metavar='file_in',
                        help='Filename of Raven output (Hydrographs.csv).')
    parser.add_argument('-o', '--file_out', action='store',
                        default=file_out, dest='file_out', metavar='file_out',
                        help='Filename of output file that will contain the metrics.')
    parser.add_argument('-s', '--start_date', action='store',
                        default=start_date, dest='start_date', metavar='start_date',
                        help='Start date of period to derive metric for (format: YYYY-MM-DD).')
    parser.add_argument('-e', '--end_date', action='store',
                        default=end_date, dest='end_date', metavar='end_date',
                        help='End date of period to derive metric for (format: YYYY-MM-DD).')

    args        = parser.parse_args()
    file_in     = args.file_in
    file_out    = args.file_out
    start_date  = args.start_date
    end_date    = args.end_date

    del parser, args
    # Comment|Uncomment - End

    # -----------------------
    # add subolder scripts/lib to search path
    # -----------------------
    import sys
    import os
    dir_path = os.path.dirname(os.path.realpath(__file__))
    sys.path.append(dir_path+'/lib')

    from read_raven_output import read_raven_hydrograph     # in lib/
    import errormeasures                                    # in lib/
    import datetime as datetime
    import numpy as np


    # -----------------------
    # getting things done
    # -----------------------

    if file_in is None:
        raise ValueError("Specify input file containing simulated and observed hydrograph.")

    if file_out is None:
        raise ValueError("Specify output file name which will contain the derived metrics.")

    if start_date is None:
        raise ValueError("Start date needs to be provided. Format: YYYY-MM-DD")
    else:
        start_date = datetime.datetime( int(start_date[0:4]), int(start_date[5:7]), int(start_date[8:10]), 0, 0 )

    if end_date is None:
        raise ValueError("End date needs to be provided. Format: YYYY-MM-DD")
    else:
        end_date = datetime.datetime( int(end_date[0:4]), int(end_date[5:7]), int(end_date[8:10]), 0, 0 )



    result = read_raven_hydrograph(file_in,start_date=start_date,end_date=end_date)   # results['Qsim'], results['Qobs']

    Qobs_valid = np.ma.masked_invalid(result['Qobs'])
    Qsim_valid = np.ma.masked_invalid(result['Qsim'])

    msk = (~Qobs_valid.mask & ~Qsim_valid.mask)

    print('total number of datapoints = ',len(msk))
    print('number of valid datapoints = ', np.sum(msk))

    Qobs_valid = Qobs_valid[msk]
    Qsim_valid = Qsim_valid[msk]

    # standard statistics
    nse     = float(errormeasures.nse(Qobs_valid,Qsim_valid))
    kge     = float(errormeasures.kge(Qobs_valid,Qsim_valid))
    kge_a   = (1.0 - float(np.std(Qsim_valid)  / np.std(Qobs_valid)))**2         # relative variability
    kge_b   = (1.0 - float(np.mean(Qsim_valid) / np.mean(Qobs_valid)))**2        # bias
    kge_r   = (1.0 - float(np.corrcoef(Qobs_valid, Qsim_valid)[0, 1]))**2        # pearson correlation coefficient
    kge_ab  = kge_a + kge_b
    kge_ar  = kge_a + kge_r
    kge_br  = kge_b + kge_r

    kge_a   = 1.0 - np.sqrt( kge_a )
    kge_b   = 1.0 - np.sqrt( kge_b )
    kge_r   = 1.0 - np.sqrt( kge_r )
    kge_ab  = 1.0 - np.sqrt( kge_ab )
    kge_ar  = 1.0 - np.sqrt( kge_ar )
    kge_br  = 1.0 - np.sqrt( kge_br )



    # statistics for low/high values
    mskzero = ( ~(Qobs_valid<=0.0) & ~(Qsim_valid<=0.0) )
    Qobs_valid_nonzero = Qobs_valid[mskzero]
    Qsim_valid_nonzero = Qsim_valid[mskzero]

    qthres  = np.min(Qobs_valid_nonzero) + (np.max(Qobs_valid_nonzero) - np.min(Qobs_valid_nonzero)) * 0.05
    idxlow  = np.where( Qobs_valid_nonzero <= qthres )[0]
    idxhgh  = np.where( Qobs_valid_nonzero >  qthres )[0]
    # KGE of lower values  :: KGE of logQ for values up to qmin+(qmax-qmin)*0.05  (not p5 !!)
    lkgeqlow05 = float(errormeasures.kge(np.log(Qobs_valid_nonzero[idxlow]),np.log(Qsim_valid_nonzero[idxlow])))
    # KGE of higher values :: KGE of logQ for values larger than qmin+(qmax-qmin)*0.05  (not p5 !!)
    lkgeqhgh95 = float(errormeasures.kge(np.log(Qobs_valid_nonzero[idxhgh]),np.log(Qsim_valid_nonzero[idxhgh])))

    print("number low  Q values (Q <= {}): {}".format(qthres,len(idxlow)))
    print("number high Q values (Q >  {}): {}".format(qthres,len(idxhgh)))


    # write results
    print('kge, kge_a, kge_b, kge_r, kge_ab, kge_ar, kge_br, lkgeqlow05, lkgeqhgh95')
    print(', '.join([ str(ii) for ii in [kge, kge_a, kge_b, kge_r, kge_ab, kge_ar, kge_br, lkgeqlow05, lkgeqhgh95] ])+'\n')

    f = open(file_out, "w")
    f.write('kge, kge_a, kge_b, kge_r, kge_ab, kge_ar, kge_br, lkgeqlow05, lkgeqhgh95\n')
    f.write( ', '.join([ str(ii) for ii in [kge, kge_a, kge_b, kge_r, kge_ab, kge_ar, kge_br, lkgeqlow05, lkgeqhgh95] ])+'\n' )
    f.close()
