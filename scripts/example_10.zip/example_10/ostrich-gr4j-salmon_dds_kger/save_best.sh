#!/bin/bash

set -e

echo "saving input files for the best solution found ..."

if [ ! -e best ] ; then
    mkdir best
fi

cp model/raven-gr4j-salmon.rvi  best/raven-gr4j-salmon.rvi
cp model/raven-gr4j-salmon.rvh  best/raven-gr4j-salmon.rvh
cp model/raven-gr4j-salmon.rvt  best/raven-gr4j-salmon.rvt
cp model/raven-gr4j-salmon.rvc  best/raven-gr4j-salmon.rvc
cp model/raven-gr4j-salmon.rvp  best/raven-gr4j-salmon.rvp
cp model/output/Diagnostics.csv best/Diagnostics.csv
cp model/output/Diagnostics_extended.csv best/Diagnostics_extended.csv
cp model/output/Hydrographs.csv best/Hydrographs.csv

exit 0
