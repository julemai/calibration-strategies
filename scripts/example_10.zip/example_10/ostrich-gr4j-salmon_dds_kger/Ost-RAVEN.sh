#!/bin/bash

set -e

cp ./raven-gr4j-salmon.rvp model/raven-gr4j-salmon.rvp
cp ./raven-gr4j-salmon.rvc model/raven-gr4j-salmon.rvc

cd model

# "./Raven_rev373_MacOS.exe"  derives different KGE/NSE values for some reason ... I want them to match the values derived in "derive_metrics"
./Raven_rev254_MacOS.exe raven-gr4j-salmon -o output/
python derive_metrics.py -i output/Hydrographs.csv -o output/Diagnostics_extended.csv -s '1991-01-01' -e '2011-01-01'

cd ..

exit 0
